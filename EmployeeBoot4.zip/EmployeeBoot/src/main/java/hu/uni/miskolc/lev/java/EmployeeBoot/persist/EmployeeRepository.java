package hu.uni.miskolc.lev.java.EmployeeBoot.persist;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employee;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EmployeeRepository extends CrudRepository <Employee, Integer>{
    List<Employee> findAllByHourCountIsLessThan(int hourCount);
    List<Employee> findAllByEmployer_Id(int employerId);
}