package hu.uni.miskolc.lev.java.EmployeeBoot.service;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.EmployeeRepository;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employee;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employer;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmployeeSericeImpl implements EmployeeService{
    private EmployeeRepository employeeRepository;
    @Override
    public void hireEmployee(Employee employee) {
        employeeRepository.save(employee);
    }

    @Override
    public void fireEmployee(Employee employee) {
        employeeRepository.delete(employee);
    }

    @Override
    public List<Employee> getAllEmployee() {
        return (List<Employee>) employeeRepository.findAll();
    }


    @Override
    public void AddHourToEmployee(int employeeId, int hour) {
        Employee employee = employeeRepository.findById(employeeId).get();
        employee.setHourCount(employee.getHourCount()+hour);
        employeeRepository.save(employee);
    }

    @Override
    public List<Employee> getEmployeesByEmployerId(int EmployerId) {
       return employeeRepository.findAllByEmployer_Id(EmployerId);
    }

}