package hu.uni.miskolc.lev.java.EmployeeBoot.service;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employer;
import java.util.List;
public interface EmployerService {
    void AddEmployer(Employer employer);
    void DeleteEmployer(Employer employer);
    List<Employer> GetAllEmployer();

}