package hu.uni.miskolc.lev.java.EmployeeBoot.service;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employee;
import java.util.List;
public interface EmployeeService {
    void hireEmployee(Employee employee);
    void fireEmployee(Employee employee);
    List<Employee> getAllEmployee();
    void AddHourToEmployee(int employeeId, int hour);
    List <Employee> getEmployeesByEmployerId(int employerId);
}