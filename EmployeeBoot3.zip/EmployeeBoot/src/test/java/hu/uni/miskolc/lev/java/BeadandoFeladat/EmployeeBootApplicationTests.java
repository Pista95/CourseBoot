package hu.uni.miskolc.lev.java.BeadandoFeladat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
