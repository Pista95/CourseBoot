package hu.uni.miskolc.lev.java.BeadandoFeladat.service;
import hu.uni.miskolc.lev.java.BeadandoFeladat.EmployeeDTO;
import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.EmployeeRepository;
import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.EmployerRepository;
import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.entity.Employee;

import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.entity.Employer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmployeeSericeImp implements EmployeeService{
    private EmployerRepository employerRepository;
    private EmployeeRepository employeeRepository;
    private EmployerService employerService;
    @Autowired
    public EmployeeSericeImp(EmployeeRepository employeeRepository, EmployerService employerService) {
        this.employeeRepository = employeeRepository;
        this.employerService= employerService;
    }
    @Override
    public void hideEmployee(Employee employee){
        employee.setEmployer(employerRepository.findById(employee.getId()).get());
        employeeRepository.save(employee);
    }

/*
    public void hideEmployee(EmployeeDTO employeeDTO){

        Employee employee = new Employee();
        employee.setName(employeeDTO.getName());
        employee.setAge(employeeDTO.getAge());
        employee.setHourCount(employeeDTO.getHourCount());
        employee.setSalary(employeeDTO.getSalary());
        employee.setEmployer(employerRepository.findById(employeeDTO.getEmployer_id()).get());
        employeeRepository.save(employee);


    }

 */

    @Override
    public void fireEmployee(Employee employee) {
        employeeRepository.delete(employee);
    }

    @Override
    public List<Employee> getAllEmployee() {
        return (List<Employee>) employeeRepository.findAll();
    }

    @Override
    public List<Employee>getLazyEmployees(int hour){
        return employeeRepository.findAllByHourCountIsLessThan(hour);
    }

    @Override
    public void addHourToEmployee(int employeeId, int hour){
      Employee employee = employeeRepository.findById(employeeId).get();
      //employeeRepository.deleteById(employeeId);
      employee.setHourCount(employee.getHourCount()+hour);
      employeeRepository.save(employee);
    }

    @Override
    public List<Employee> getEmployeesByEmployerId(int employerId) {
      return employeeRepository.findAllByEmployer_Id(employerId);
    }
}