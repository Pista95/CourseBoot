package hu.uni.miskolc.lev.java.BeadandoFeladat.persist;
import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.entity.Employer;
import org.springframework.data.repository.CrudRepository;
public interface EmployerRepository extends CrudRepository <Employer, Integer> {
}
