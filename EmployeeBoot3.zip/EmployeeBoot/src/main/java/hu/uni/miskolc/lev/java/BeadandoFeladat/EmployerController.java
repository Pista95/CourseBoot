package hu.uni.miskolc.lev.java.BeadandoFeladat;
import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.entity.Employer;
import hu.uni.miskolc.lev.java.BeadandoFeladat.service.EmployerService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import java.util.List;
@Controller
public class EmployerController {
    private EmployerService employerService;

    public EmployerController(EmployerService employerService) {
        this.employerService = employerService;
    }

    @PostMapping("addEmployer")
    @ResponseBody
    public void addEmployer(@RequestBody Employer employer){
        employerService.addEmployer(employer);
    }
    @GetMapping("getAllEmployer")
    @ResponseBody
    public List<Employer> getAllEmployer(){
        return employerService.getAllEmployer();
    }

}