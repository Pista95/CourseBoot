package hu.uni.miskolc.lev.java.EmployeeBoot.service;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.ProfileRepository;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.StudentRepository;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Profile;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProfileServiceImpl implements ProfileService{
    private ProfileRepository profileRepository;

    @Autowired
    public ProfileServiceImpl(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
    }


    @Override
    public void addProfile(Profile profile) {
        profileRepository.save(profile);
    }

    @Override
    public void deleteProfile(Profile profile) {
        profileRepository.delete(profile);
    }

    @Override
    public List<Profile> getAllProfile() {
        return (List<Profile>) profileRepository.findAll();
    }
}