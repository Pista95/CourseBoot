package hu.uni.miskolc.lev.java.EmployeeBoot.service;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Student;

import java.util.List;

public interface StudentService {
    void addStudent(Student student);

    void deleteStudent(Student student);
    List<Student> getAllStudent();
}
