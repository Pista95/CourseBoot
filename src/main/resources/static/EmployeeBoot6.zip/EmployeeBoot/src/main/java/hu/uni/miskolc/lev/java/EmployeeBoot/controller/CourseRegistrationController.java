package hu.uni.miskolc.lev.java.EmployeeBoot.controller;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Course;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.CourseRegistration;
import hu.uni.miskolc.lev.java.EmployeeBoot.service.CourseRegistrationService;
import hu.uni.miskolc.lev.java.EmployeeBoot.service.CourseService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class CourseRegistrationController {
    private CourseRegistrationService courseRegistrationService;
    public CourseRegistrationController(CourseRegistrationService courseRegistrationService) {
        this.courseRegistrationService =courseRegistrationService;
    }

    @PostMapping("addCourseRegistration")
    @ResponseBody
    public void addCourseRegistration(@RequestBody CourseRegistration courseRegistration){
        courseRegistrationService.addCourseRegistration(courseRegistration);
    }

    @GetMapping("getAllCourseRegistration")
    @ResponseBody
    public List<CourseRegistration> getAllCourseRegistration(){

        return courseRegistrationService.getAllCourseRegistration();
    }
}
