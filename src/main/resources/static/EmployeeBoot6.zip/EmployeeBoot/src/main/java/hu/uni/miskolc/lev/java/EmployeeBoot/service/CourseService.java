package hu.uni.miskolc.lev.java.EmployeeBoot.service;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Course;

import java.util.List;

public interface CourseService {
    void addCourse(Course course);
    void deleteCourse(Course course);
    List<Course> getAllCourse();
}