package hu.uni.miskolc.lev.java.EmployeeBoot.persist;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Profile;
import org.springframework.data.repository.CrudRepository;

public interface ProfileRepository extends CrudRepository<Profile, Integer> { }
