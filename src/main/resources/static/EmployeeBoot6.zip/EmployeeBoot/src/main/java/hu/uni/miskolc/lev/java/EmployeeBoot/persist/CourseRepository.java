package hu.uni.miskolc.lev.java.EmployeeBoot.persist;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Course;
import org.springframework.data.repository.CrudRepository;

public interface CourseRepository extends CrudRepository<Course, Integer> { }