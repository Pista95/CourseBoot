package hu.uni.miskolc.lev.java.EmployeeBoot.service;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.CourseRegistration;

import java.util.List;

public interface CourseRegistrationService {
    void addCourseRegistration(CourseRegistration courseregistration);
    List<CourseRegistration> getAllCourseRegistration();
}
