package hu.uni.miskolc.lev.java.EmployeeBoot.service;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.EmployeeEntity;
import java.util.List;
public interface EmployeeService {
    void hireEmployee(EmployeeEntity employee);
    void fireEmployee(EmployeeEntity employee);
    List<EmployeeEntity> getAllEmployee();
    void AddHourToEmployee(int employeeId, int hour);
    List <EmployeeEntity> getEmployeesByEmployerId(int employerId);
}