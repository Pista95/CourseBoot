package hu.uni.miskolc.lev.java.EmployeeBoot.persist;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.CourseRegistration;
import org.springframework.data.repository.CrudRepository;

public interface CourseRegistrationRepository extends CrudRepository<CourseRegistration, Integer> { }



