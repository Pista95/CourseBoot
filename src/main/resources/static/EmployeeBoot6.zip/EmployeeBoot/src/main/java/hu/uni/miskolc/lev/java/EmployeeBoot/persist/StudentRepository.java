package hu.uni.miskolc.lev.java.EmployeeBoot.persist;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Student;
import org.springframework.data.repository.CrudRepository;

    public interface StudentRepository extends CrudRepository<Student, Integer> { }


