package hu.uni.miskolc.lev.java.EmployeeBoot.service;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Profile;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Student;

import java.util.List;


    public interface ProfileService {
        void addProfile(Profile profile);
        void deleteProfile(Profile profile);
        List<Profile> getAllProfile();
    }

