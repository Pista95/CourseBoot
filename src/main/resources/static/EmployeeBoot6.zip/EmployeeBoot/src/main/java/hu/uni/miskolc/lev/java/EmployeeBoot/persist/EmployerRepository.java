package hu.uni.miskolc.lev.java.EmployeeBoot.persist;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.EmployerEntity;
import org.springframework.data.repository.CrudRepository;
public interface EmployerRepository extends CrudRepository <EmployerEntity, Integer> {
}
