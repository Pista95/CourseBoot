package hu.uni.miskolc.lev.java.EmployeeBoot.service;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.EmployerRepository;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employee;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmployerServiceImp implements EmployerService {
    private EmployerRepository employerRepository;

    @Autowired
    public EmployerServiceImp(EmployerRepository employerRepository) {
        this.employerRepository = employerRepository;
    }


    @Override
    public void addEmployer(Employer employer) {
        employerRepository.save(employer);

    }

    @Override
    public void deleteEmployer(Employer employer) {
        employerRepository.delete(employer);
    }

    @Override
    public List<Employer> getAllEmployer() {
        return (List<Employer>) employerRepository.findAll();
    }

}