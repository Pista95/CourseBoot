package hu.uni.miskolc.lev.java.EmployeeBoot.service;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.EmployeeRepository;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employee;

import java.util.List;

public class EmployeeSericeImp implements EmployeeService{
    private EmployeeRepository employeeRepository;

    @Override
    public void hideEmployee(Employee employee) {
       employeeRepository.save(employee);
    }

    @Override
    public void fireEmployee(Employee employee) {
        employeeRepository.delete(employee);
    }

    @Override
    public List<Employee> getAllEmployee() {
        return (List<Employee>) employeeRepository.findAll();
    }
    @Override
    public List<Employee>getLazyEmployees(int hour){
        return employeeRepository.findAllByHourCountIsLessThan(hour);
    }
    @Override
   public void addHourToEmployee(int employeeId, int hour){
      Employee employee = employeeRepository.findById(employeeId).get();
      //employeeRepository.deleteById(employeeId);
      employee.setHourCount(employee.getHourCount()+hour);
      employeeRepository.save(employee);
   }

    @Override
    public List<Employee> getEmployeesByEmployerId(int employerId) {

      return employeeRepository.findAllByEmployer_Id(employerId);
    }

}
