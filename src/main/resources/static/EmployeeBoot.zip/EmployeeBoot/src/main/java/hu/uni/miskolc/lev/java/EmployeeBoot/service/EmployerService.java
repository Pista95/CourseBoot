package hu.uni.miskolc.lev.java.EmployeeBoot.service;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employee;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employer;

import java.util.List;

public interface EmployerService {
    void addEmployer(Employer employer);
    void deleteEmployer(Employer employer);
    List<Employer> getAllEmployer();
}
