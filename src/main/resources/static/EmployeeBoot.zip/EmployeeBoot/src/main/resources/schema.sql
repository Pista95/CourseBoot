DROP TABLE IF EXISTS  book;
CREATE TABLE IF NOT EXISTS book (
                               id INT AUTO_INCREMENT PRIMARY KEY,
                               isbn INT (10) NOT NULL,
                               title VARCHAR(50) NOT NULL,
                               author VARCHAR(20) NOT NULL,
                               date DATE
);
INSERT INTO book(isbn,title,author,date) VALUES (1,'Ramesh','Ahmedabad',CURRENT_DATE);
INSERT INTO book(isbn,title,author,date) VALUES (2,'k2','Ahmedabad',CURRENT_DATE);
