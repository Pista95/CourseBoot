package hu.uni.miskolc.lev.java.EmployeeBoot.persist;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employee;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employer;
import org.springframework.data.repository.CrudRepository;

public interface EmployerRepository extends CrudRepository <Employer, Integer> {

}
