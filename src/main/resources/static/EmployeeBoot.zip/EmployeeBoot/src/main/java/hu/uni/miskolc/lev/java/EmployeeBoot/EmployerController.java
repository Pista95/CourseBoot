package hu.uni.miskolc.lev.java.EmployeeBoot;

import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.Employer;
import hu.uni.miskolc.lev.java.EmployeeBoot.service.EmployerService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class EmployerController {
    private EmployerService employerService;

    public EmployerController(EmployerService employerService) {
        this.employerService = employerService;
    }

    @PostMapping("addEmployer")
    @ResponseBody
    public void addEmployer(@RequestBody Employer employer){
        employerService.addEmployer(employer);
    }

}