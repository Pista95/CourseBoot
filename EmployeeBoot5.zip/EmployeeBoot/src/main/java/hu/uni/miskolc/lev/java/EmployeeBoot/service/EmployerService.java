package hu.uni.miskolc.lev.java.EmployeeBoot.service;
import hu.uni.miskolc.lev.java.EmployeeBoot.persist.entity.EmployerEntity;
import java.util.List;
public interface EmployerService {
    void AddEmployer(EmployerEntity employerEntity);
    void DeleteEmployer(EmployerEntity employerEntity);
    List<EmployerEntity> GetAllEmployer();

}