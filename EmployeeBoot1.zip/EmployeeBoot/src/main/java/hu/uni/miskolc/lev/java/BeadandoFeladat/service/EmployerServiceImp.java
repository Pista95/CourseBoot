package hu.uni.miskolc.lev.java.BeadandoFeladat.service;
import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.EmployerRepository;
import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.entity.Employer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class EmployerServiceImp implements EmployerService {
    private EmployerRepository employerRepository;

    @Autowired
    public EmployerServiceImp(EmployerRepository employerRepository) {
        this.employerRepository = employerRepository;
    }

    @Override
    public void addEmployer(Employer employer) {
        employerRepository.save(employer);}

    @Override
    public void deleteEmployer(Employer employer) {
        employerRepository.delete(employer);
    }

    @Override
    public List<Employer> getAllEmployer() {
        return (List<Employer>) employerRepository.findAll();
    }

}