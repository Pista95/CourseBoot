package hu.uni.miskolc.lev.java.BeadandoFeladat.service;
import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.entity.Employer;
import java.util.List;
public interface EmployerService {
    void addEmployer(Employer employer);
    void deleteEmployer(Employer employer);
    List<Employer> getAllEmployer();
}