package hu.uni.miskolc.lev.java.BeadandoFeladat.service;
import hu.uni.miskolc.lev.java.BeadandoFeladat.persist.entity.Employee;
import java.util.List;
public interface EmployeeService {
    void hideEmployee(Employee employee);
    void fireEmployee(Employee employee);
    List<Employee> getAllEmployee();
    List<Employee>getLazyEmployees(int hour);
    void addHourToEmployee(int employeeId, int hour);
    List <Employee> getEmployeesByEmployerId(int EmployerId);
}